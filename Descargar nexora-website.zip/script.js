const form = document.getElementById('comment-form');
const commentsList = document.getElementById('comments-list');

form.addEventListener('submit', function(e) {
  e.preventDefault();

  const name = document.getElementById('name').value.trim();
  const comment = document.getElementById('comment').value.trim();

  if (name && comment) {
    const commentDiv = document.createElement('div');
    commentDiv.classList.add('comment');

    commentDiv.innerHTML = \`
      <strong>\${escapeHTML(name)}</strong> dice:
      <p>\${escapeHTML(comment)}</p>
      <hr>
    \`;

    commentsList.prepend(commentDiv);
    form.reset();
  }
});

function escapeHTML(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
